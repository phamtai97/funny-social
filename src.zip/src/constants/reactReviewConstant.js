export const reactReviewConstant = {
    SET_TYPE_REACT:'SET_TYPE_REACT',
}
