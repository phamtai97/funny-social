export const requestApiConstant = {
    POST: 'POST',
    GET: 'GET',
    PUT: 'PUT',
    DELETE: 'DELETE',
    REQUESTING: 'REQUESTING',
    REQUEST_SUCCESS: 'REQUEST_SUCCESS',
    REQUEST_FAIL: 'REQUEST_FAIL'
}
