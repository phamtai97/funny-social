export const loginConstant = {
    IS_LOGIN_SUCCESS: 'IS_LOGIN_SUCCESS',
    LOGIN: 'LOGIN',
    IS_LOGOUT_SUCCESS: 'IS_LOGOUT_SUCESS'
}
