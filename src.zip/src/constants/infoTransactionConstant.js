export const infoTransactionConstant = {
    GET_SEQUENCE: "GET_SEQUENCE"
}
