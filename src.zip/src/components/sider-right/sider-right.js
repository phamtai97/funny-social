import React, { Component } from 'react';
import './sider-right.css';

class SiderRight extends Component{
    render(){
        return(
            <div className="sider-right">

            </div>
        )
    }
}

export default SiderRight;
