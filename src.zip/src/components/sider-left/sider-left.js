import React, { Component } from 'react';
import './sider-left.css';

class SiderLeft extends Component{
    render(){
        return(
            <div className="sider-left">

            </div>
        )
    }
}

export default SiderLeft;
